/*
 *  kempld_now1_wdt.c - Kontron PLD watchdog driver for COMe-mSP1
 *
 *  Copyright (c) 2011-2012 Kontron Europe GmbH
 *  Author: Michael Brunner <michael.brunner@kontron.com>
 *
 *  Note: The watchdog of the COMe-mSP1 (nanoETXexpress-SP) has one stage and
 *        only supports predefined watchdog timeout values.
 *
 *        The supported timeouts are:
 *              1 s, 5 s, 10 s, 30 s, 1 min, 5 min, 10 min, 15 min
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License 2 as published
 *  by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/types.h>
#include <linux/miscdevice.h>
#include <linux/watchdog.h>
#include <linux/fs.h>
#include <linux/ioport.h>
#include <linux/init.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/delay.h>
#include <linux/platform_device.h>
#include "include/linux/mfd/kempld.h"

#include "kempld_wdt.h"

#define WATCHDOG_TIMEOUT 30
static int prm_timeout = WATCHDOG_TIMEOUT;
module_param(prm_timeout, int, 0);
MODULE_PARM_DESC(prm_timeout,
		 "Watchdog timeout in seconds. (1, 5, 10, 30, 60, 300, 600, 900, default="
		 __MODULE_STRING(WATCHDOG_TIMEOUT) ")");

static int nowayout = WATCHDOG_NOWAYOUT;
module_param(nowayout, int, 0);
MODULE_PARM_DESC(nowayout,
		 "Watchdog cannot be stopped once started (default="
		 __MODULE_STRING(WATCHDOG_NOWAYOUT) ")");

/* nanoETXexpress-SP watchdog register definitions */
#define KEMPLD_WDT_NOW1					0xA2
#define		KEMPLD_WDT_NOW1_KICK_MASK		0x80
#define		KEMPLD_WDT_NOW1_ENABLE_MASK		0x40
#define		KEMPLD_WDT_NOW1_TIMEOUT_MASK		0x1f
#define			KEMPLD_WDT_NOW1_TIMEOUT_1SEC	0x00
#define			KEMPLD_WDT_NOW1_TIMEOUT_5SEC	0x01
#define			KEMPLD_WDT_NOW1_TIMEOUT_10SEC	0x02
#define			KEMPLD_WDT_NOW1_TIMEOUT_30SEC	0x03
#define			KEMPLD_WDT_NOW1_TIMEOUT_1MIN	0x10
#define			KEMPLD_WDT_NOW1_TIMEOUT_5MIN	0x11
#define			KEMPLD_WDT_NOW1_TIMEOUT_10MIN	0x12
#define			KEMPLD_WDT_NOW1_TIMEOUT_15MIN	0x13

/* delay in us necessary due to clock domain sync */
#define		KEMPLD_WDT_NOW1_SYNC_DELAY		31

static struct kempld_watchdog_data  *kempld_now1_wdt;

static int kempld_now1_wdt_read_supported;
static int kempld_now1_wdt_reg_cache;

static int kempld_now1_wdt_start(struct kempld_watchdog_data *wdt)
{
	struct kempld_device_data *pld = wdt->pld;
	int wdt_reg;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_NOW1);
	udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
	if  (kempld_now1_wdt_read_supported)
		wdt_reg = kempld_read8(pld, KEMPLD_WDT_NOW1);
	else
		wdt_reg = kempld_now1_wdt_reg_cache;
	wdt_reg |= KEMPLD_WDT_NOW1_ENABLE_MASK;
	udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
	kempld_write8(pld, KEMPLD_WDT_NOW1, wdt_reg);
	kempld_now1_wdt_reg_cache = wdt_reg;
	kempld_release_mutex(pld);

	if (kempld_now1_wdt_read_supported) {
		/* read out the register again to check if everything worked */
		kempld_get_mutex_set_index(pld, KEMPLD_WDT_NOW1);
		udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
		wdt_reg = kempld_read8(pld, KEMPLD_WDT_NOW1);
		kempld_release_mutex(pld);

		/* check if the watchdog was disabled */
		if (!(wdt_reg & KEMPLD_WDT_NOW1_ENABLE_MASK))
			return -EACCES;
	}

	return 0;
}

static int kempld_now1_wdt_stop(struct kempld_watchdog_data *wdt)
{
	struct kempld_device_data *pld = wdt->pld;
	int wdt_reg;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_NOW1);
	if  (kempld_now1_wdt_read_supported) {
		udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
		wdt_reg = kempld_read8(pld, KEMPLD_WDT_NOW1);
	} else
		wdt_reg = kempld_now1_wdt_reg_cache;
	wdt_reg &= ~KEMPLD_WDT_NOW1_ENABLE_MASK;
	udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
	kempld_write8(pld, KEMPLD_WDT_NOW1, wdt_reg);
	kempld_now1_wdt_reg_cache = wdt_reg;
	kempld_release_mutex(pld);

	if (kempld_now1_wdt_read_supported) {
		/* read out the register again to check if everything worked */
		kempld_get_mutex_set_index(pld, KEMPLD_WDT_NOW1);
		udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
		wdt_reg = kempld_read8(pld, KEMPLD_WDT_NOW1);
		kempld_release_mutex(pld);

		/* check if the watchdog was disabled */
		if (wdt_reg & KEMPLD_WDT_NOW1_ENABLE_MASK)
			return -EACCES;
	}

	return 0;
}

static int kempld_now1_wdt_keepalive(struct kempld_watchdog_data *wdt)
{
	struct kempld_device_data *pld = wdt->pld;
	int wdt_reg;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_NOW1);

	udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);

	if  (kempld_now1_wdt_read_supported) {
		wdt_reg = kempld_read8(pld, KEMPLD_WDT_NOW1);
	} else {
		wdt_reg = kempld_now1_wdt_reg_cache;
		/* write the state again to be sure the trigger register has
		 * the right level */
		kempld_write8(pld, KEMPLD_WDT_NOW1, wdt_reg);
	}

	if (wdt_reg & KEMPLD_WDT_NOW1_KICK_MASK)
		wdt_reg &= ~KEMPLD_WDT_NOW1_KICK_MASK;
	else
		wdt_reg |= KEMPLD_WDT_NOW1_KICK_MASK;

	udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);

	kempld_write8(pld, KEMPLD_WDT_NOW1, wdt_reg);

	kempld_now1_wdt_reg_cache = wdt_reg;

	kempld_release_mutex(pld);

	return 0;
}


static int kempld_now1_wdt_settimeout(struct kempld_watchdog_data *wdt,
				      int check_only)
{
	struct kempld_device_data *pld = wdt->pld;
	int wdt_reg;
	int ret = 0;
	int enabled = 0;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_NOW1);

	if  (kempld_now1_wdt_read_supported) {
		udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
		wdt_reg = kempld_read8(pld, KEMPLD_WDT_NOW1);
	} else
		wdt_reg = kempld_now1_wdt_reg_cache;

	if (wdt_reg & KEMPLD_WDT_NOW1_ENABLE_MASK)
		enabled = 1;

	wdt_reg = ~(KEMPLD_WDT_NOW1_TIMEOUT_MASK
		    | KEMPLD_WDT_NOW1_ENABLE_MASK);

	switch (wdt->timeout) {
	case 1:
		wdt_reg |= KEMPLD_WDT_NOW1_TIMEOUT_1SEC;
		break;
	case 5:
		wdt_reg |= KEMPLD_WDT_NOW1_TIMEOUT_5SEC;
		break;
	case 10:
		wdt_reg |= KEMPLD_WDT_NOW1_TIMEOUT_10SEC;
		break;
	case 30:
		wdt_reg |= KEMPLD_WDT_NOW1_TIMEOUT_30SEC;
		break;
	case 60:
		wdt_reg |= KEMPLD_WDT_NOW1_TIMEOUT_1MIN;
		break;
	case 300:
		wdt_reg |= KEMPLD_WDT_NOW1_TIMEOUT_5MIN;
		break;
	case 600:
		wdt_reg |= KEMPLD_WDT_NOW1_TIMEOUT_10MIN;
		break;
	case 900:
		wdt_reg |= KEMPLD_WDT_NOW1_TIMEOUT_15MIN;
		break;
	default:
		ret = -EINVAL;
		dev_err(wdt->pld->dev,
			"Invalid timeout value given!\n");
	}

	if (!check_only) {
		if (ret == 0) {
			/* WDT needs to be disabled before the timeout can be
			 * changed */
			udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
			kempld_write8(pld, KEMPLD_WDT_NOW1, wdt_reg);
			if (enabled)
				wdt_reg |= KEMPLD_WDT_NOW1_ENABLE_MASK;
			udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
			kempld_write8(pld, KEMPLD_WDT_NOW1, wdt_reg);
		}
	}

	kempld_now1_wdt_reg_cache = wdt_reg;

	kempld_release_mutex(pld);

	return ret;
}

static int kempld_now1_wdt_gettimeout(struct kempld_watchdog_data *wdt,
				 struct kempld_watchdog_stage *stage)
{
	struct kempld_device_data *pld = wdt->pld;
	int wdt_reg;
	int timeout;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_NOW1);

	if  (kempld_now1_wdt_read_supported) {
		udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
		wdt_reg = kempld_read8(pld, KEMPLD_WDT_NOW1);
		kempld_now1_wdt_reg_cache = wdt_reg;
	} else
		wdt_reg = kempld_now1_wdt_reg_cache;

	kempld_release_mutex(pld);

	switch (wdt_reg & KEMPLD_WDT_NOW1_TIMEOUT_MASK) {
	case KEMPLD_WDT_NOW1_TIMEOUT_1SEC:
		timeout = 1;
		break;
	case KEMPLD_WDT_NOW1_TIMEOUT_5SEC:
		timeout = 5;
		break;
	case KEMPLD_WDT_NOW1_TIMEOUT_10SEC:
		timeout = 10;
		break;
	case KEMPLD_WDT_NOW1_TIMEOUT_30SEC:
		timeout = 30;
		break;
	case KEMPLD_WDT_NOW1_TIMEOUT_1MIN:
		timeout = 60;
		break;
	case KEMPLD_WDT_NOW1_TIMEOUT_5MIN:
		timeout = 300;
		break;
	case KEMPLD_WDT_NOW1_TIMEOUT_10MIN:
		timeout = 600;
		break;
	case KEMPLD_WDT_NOW1_TIMEOUT_15MIN:
		timeout = 900;
		break;
	default:
		timeout = -ERANGE;
	}

	return timeout;
}

static ssize_t kempld_now1_wdt_write(struct file *file, const char __user
				     *data, size_t count, loff_t *ppos)
{
	struct kempld_watchdog_data *wdt = kempld_now1_wdt;

	BUG_ON(wdt == NULL);

	if (count) {
		kempld_now1_wdt_keepalive(wdt);

		if (!nowayout) {
			size_t i;

			wdt->expect_close = 0;

			for (i = 0; i < count; i++) {
				char c;

				if (get_user(c, data+i))
					return -EFAULT;
				if (c == 'V')
					wdt->expect_close = 42;
			}
		}
	}

	return count;
}

static long kempld_now1_wdt_ioctl(struct file *file, unsigned int cmd,
			     unsigned long arg)
{
	void __user *argp = (void __user *)arg;
	int __user *p = argp;
	struct kempld_watchdog_data *wdt = kempld_now1_wdt;
	int options;
	int value;
	int ret = 0;

	BUG_ON(wdt == NULL);

	switch (cmd) {
	case WDIOC_GETSUPPORT:
		if (copy_to_user(argp, &wdt->ident, sizeof(wdt->ident)))
			ret = -EFAULT;
		break;
	case WDIOC_GETSTATUS:
	case WDIOC_GETBOOTSTATUS:
		ret = put_user(0, p);
		break;
	case WDIOC_SETOPTIONS:
		if (get_user(options, p)) {
			ret = -EFAULT;
			break;
		}
		if (options & WDIOS_DISABLECARD)
			ret = kempld_now1_wdt_stop(wdt);
		if (options & WDIOS_ENABLECARD) {
			ret = kempld_now1_wdt_start(wdt);
			kempld_now1_wdt_keepalive(wdt);
		}
		break;
	case WDIOC_KEEPALIVE:
		kempld_now1_wdt_keepalive(wdt);
		break;
	case WDIOC_SETTIMEOUT:
		if (get_user(value, p)) {
			ret = -EFAULT;
			break;
		}
		wdt->timeout = value;
		ret = kempld_now1_wdt_settimeout(wdt, 0);
		kempld_now1_wdt_keepalive(wdt);
		break;
	case WDIOC_GETTIMEOUT:
		value = kempld_now1_wdt_gettimeout(wdt, wdt->timeout_stage);
		if (value < 0)
			ret = ERANGE;
		else
			ret = put_user(value, p);
		break;
	default:
		ret = -ENOTTY;
	}

	return ret;
}

static int kempld_now1_wdt_release(struct inode *inode, struct file *file)
{
	struct kempld_watchdog_data *wdt = kempld_now1_wdt;

	BUG_ON(wdt == NULL);

	if (wdt->expect_close)
		kempld_now1_wdt_stop(wdt);
	else {
		dev_warn(wdt->pld->dev,
			 "Unexpected close, not stopping watchdog!\n");
		kempld_now1_wdt_keepalive(wdt);
	}

	kempld_now1_wdt->expect_close = 0;

	clear_bit(0, &wdt->is_open);

	return 0;
}

static int kempld_now1_wdt_open(struct inode *inode, struct file *file)
{
	int ret;
	struct kempld_watchdog_data *wdt = kempld_now1_wdt;
	struct kempld_device_data *pld = wdt->pld;
	u8 wdt_reg;

	BUG_ON(wdt == NULL);

	if (test_and_set_bit(0, &wdt->is_open))
		return -EBUSY;

	if (nowayout)
		__module_get(THIS_MODULE);

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_NOW1);
	if (kempld_now1_wdt_read_supported) {
		udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
		wdt_reg = kempld_read8(pld, KEMPLD_WDT_NOW1);
	} else {
		wdt_reg = kempld_now1_wdt_reg_cache;
	}
	kempld_now1_wdt_reg_cache = wdt_reg;
	kempld_release_mutex(pld);

	/* kick the watchdog if it is already enabled, otherwise start it */
	if (wdt_reg & KEMPLD_WDT_NOW1_ENABLE_MASK) {
		kempld_now1_wdt_keepalive(wdt);
	} else {
		ret = kempld_now1_wdt_settimeout(wdt, 0);
		if (ret)
			goto err_enable_wdt;
		ret = kempld_now1_wdt_start(wdt);
		if (ret)
			goto err_enable_wdt;
	}

	return nonseekable_open(inode, file);

err_enable_wdt:
	dev_err(wdt->pld->dev, "Failed to enable the watchdog timer!\n");
	wdt->expect_close = 1;
	kempld_now1_wdt_release(inode, file);

	return ret;
}

static const struct file_operations kempld_now1_wdt_fops = {
	.owner		= THIS_MODULE,
	.llseek		= no_llseek,
	.write		= kempld_now1_wdt_write,
	.unlocked_ioctl	= kempld_now1_wdt_ioctl,
	.open		= kempld_now1_wdt_open,
	.release	= kempld_now1_wdt_release,
};

static struct miscdevice kempld_now1_wdt_miscdev = {
	.minor	= WATCHDOG_MINOR,
	.name	= "watchdog",
	.fops	= &kempld_now1_wdt_fops,
};

static int kempld_now1_wdt_probe(struct platform_device *pdev)
{
	struct kempld_watchdog_data *wdt;
	struct kempld_device_data *pld;
	u8 wdt_reg;
	int ret;

	if (kempld_now1_wdt != NULL) {
		dev_err(&pdev->dev,
			"unable to support more than one watchdog devices\n");
		return -EMFILE;
	}

	wdt = kzalloc(sizeof(struct kempld_watchdog_data), GFP_KERNEL);
	if (wdt == NULL) {
		ret = -ENOMEM;
		goto err_alloc_dev_data;
	}

	wdt->timeout_stage = kzalloc(sizeof(struct kempld_watchdog_stage),
				     GFP_KERNEL);
	if (wdt->timeout_stage == NULL) {
		ret = -ENOMEM;
		goto err_alloc_dev_data;
	}

	wdt->stages = 1;
	wdt->stage[0] = wdt->timeout_stage;

	pld = dev_get_drvdata(pdev->dev.parent);
	wdt->pld = pld;

	platform_set_drvdata(pdev, wdt);

	strncpy(wdt->ident.identity, "nanoETXexpress-SP Watchdog",
		sizeof(wdt->ident.identity));

	/* set default values for the case we start the watchdog or change
	 * the configuration */
	wdt->timeout = prm_timeout;

	/* use settimeout to check if the timeout parameter is valid */
	ret = kempld_now1_wdt_settimeout(wdt, 1);
	if (ret)
		goto err_check_timeout;
	wdt->ident.firmware_version = (pld->info.major<<8) + pld->info.minor;
	if (pld->info.major > 67)
		kempld_now1_wdt_read_supported = 1;
	else
		dev_info(wdt->pld->dev,
			 "Watchdog revision does not support read - unable to get watchdog state!\n");

	/* get initial watchdog status */
	kempld_get_mutex_set_index(pld, KEMPLD_WDT_NOW1);
	if (kempld_now1_wdt_read_supported) {
		udelay(KEMPLD_WDT_NOW1_SYNC_DELAY);
		wdt_reg = kempld_read8(pld, KEMPLD_WDT_NOW1);
	} else {
		wdt_reg = 0x0;
	}
	kempld_now1_wdt_reg_cache = wdt_reg;
	kempld_release_mutex(wdt->pld);

	/* check if watchdog is enabled */
	if (wdt_reg & KEMPLD_WDT_NOW1_ENABLE_MASK)
		dev_info(wdt->pld->dev, "Watchdog is already enabled!\n");

	wdt->ident.options = WDIOF_KEEPALIVEPING;
	wdt->ident.options |= WDIOF_SETTIMEOUT;
	if (!nowayout)
		wdt->ident.options |= WDIOF_MAGICCLOSE;

	kempld_now1_wdt = wdt;

	ret = misc_register(&kempld_now1_wdt_miscdev);
	if (ret)
		goto err_misc_register;

	dev_info(wdt->pld->dev, "watchdog initialized\n");

	return 0;

err_misc_register:
	kfree(kempld_now1_wdt);
	kempld_now1_wdt = NULL;
err_check_timeout:
err_alloc_dev_data:
	return ret;
}

static int kempld_now1_wdt_remove(struct platform_device *pdev)
{
	struct kempld_watchdog_data *wdt = platform_get_drvdata(pdev);

	BUG_ON(wdt != kempld_now1_wdt);

	/* stop or at least keepalive the watchdog before we leave */
	if (wdt != NULL) {
		if (!nowayout)
			kempld_now1_wdt_stop(wdt);
		else
			kempld_now1_wdt_keepalive(wdt);
	}

	misc_deregister(&kempld_now1_wdt_miscdev);

	kfree(wdt);
	kempld_now1_wdt = NULL;
	platform_set_drvdata(pdev, NULL);

	return 0;
}

static struct platform_driver kempld_now1_wdt_driver = {
	.driver = {
		.name = "kempld_now1-wdt",
		.owner = THIS_MODULE,
	},
	.probe = kempld_now1_wdt_probe,
	.remove = kempld_now1_wdt_remove,
};

static int __init kempld_now1_wdt_init(void)
{
	return platform_driver_register(&kempld_now1_wdt_driver);
}

static void __exit kempld_now1_wdt_exit(void)
{
	platform_driver_unregister(&kempld_now1_wdt_driver);
}

module_init(kempld_now1_wdt_init);
module_exit(kempld_now1_wdt_exit);

MODULE_DESCRIPTION("KEM PLD nanoETXexpress-SP Watchdog Driver");
MODULE_AUTHOR("Michael Brunner <michael.brunner@kontron.com>");
MODULE_LICENSE("GPL");
MODULE_ALIAS_MISCDEV(WATCHDOG_MINOR);
MODULE_VERSION("34.0");
