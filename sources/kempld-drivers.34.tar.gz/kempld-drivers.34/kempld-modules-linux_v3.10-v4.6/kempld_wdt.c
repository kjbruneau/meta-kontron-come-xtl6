/*
 *  kempld_wdt.c - Kontron PLD watchdog driver
 *
 *  Copyright (c) 2010-2012 Kontron Europe GmbH
 *  Author: Michael Brunner <michael.brunner@kontron.com>
 *
 *  Note: From the PLD watchdog point of view timeout and pretimeout are
 *        defined differently than in the kernel.
 *        First the pretimeout stage runs out before the timeout stage gets
 *        active. This has to be kept in mind.
 *
 *  Kernel/API:                     P-----| pretimeout
 *                |-----------------------T timeout
 *  Watchdog:     |-----------------P       pretimeout_stage
 *                                  |-----T timeout_stage
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License 2 as published
 *  by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/types.h>
#include <linux/miscdevice.h>
#include <linux/watchdog.h>
#include <linux/fs.h>
#include <linux/ioport.h>
#include <linux/init.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/platform_device.h>
#include "include/linux/mfd/kempld.h"

#include "kempld_wdt.h"

#define WATCHDOG_DEFAULT_TIMEOUT 20
#define WATCHDOG_DEFAULT_PRETIMEOUT 0
static int timeout = -1;
static int pretimeout = -1;
/* The maximum timeout values have to be probed */
module_param(timeout, int, 0);
MODULE_PARM_DESC(timeout,
		 "Watchdog timeout in seconds. (>0, default="
		__MODULE_STRING(WATCHDOG_DEFAULT_TIMEOUT) ")");
module_param(pretimeout, int, 0);
MODULE_PARM_DESC(pretimeout,
		 "Watchdog pretimeout in seconds. (>=0, default="
		__MODULE_STRING(WATCHDOG_DEFAULT_PRETIMEOUT) ")");

static int nowayout = WATCHDOG_NOWAYOUT;
module_param(nowayout, int, 0);
MODULE_PARM_DESC(nowayout,
		 "Watchdog cannot be stopped once started (default="
		 __MODULE_STRING(WATCHDOG_NOWAYOUT) ")");

static struct kempld_watchdog_data  *kempld_wdt;

static int kempld_wdt_start(struct kempld_watchdog_data *wdt)
{
	struct kempld_device_data *pld = wdt->pld;
	u8 status;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_CFG);

	status = kempld_read8(pld, KEMPLD_WDT_CFG);
	status |= KEMPLD_WDT_CFG_ENABLE;
	kempld_write8(pld, KEMPLD_WDT_CFG, status);
	status = kempld_read8(pld, KEMPLD_WDT_CFG);

	kempld_release_mutex(pld);

	/* check if the watchdog was enabled */
	if (!(status & KEMPLD_WDT_CFG_ENABLE))
		return -EACCES;

	return 0;
}

static int kempld_wdt_stop(struct kempld_watchdog_data *wdt)
{
	struct kempld_device_data *pld = wdt->pld;
	u8 status;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_CFG);

	status = kempld_read8(pld, KEMPLD_WDT_CFG);
	status &= ~KEMPLD_WDT_CFG_ENABLE;
	kempld_write8(pld, KEMPLD_WDT_CFG, status);
	status = kempld_read8(pld, KEMPLD_WDT_CFG);

	kempld_release_mutex(pld);

	/* check if the watchdog was disabled */
	if (status & KEMPLD_WDT_CFG_ENABLE)
		return -EACCES;

	return 0;
}

static int kempld_wdt_keepalive(struct kempld_watchdog_data *wdt)
{
	struct kempld_device_data *pld = wdt->pld;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_CFG);

	kempld_write8(pld, KEMPLD_WDT_KICK, 'K');

	kempld_release_mutex(pld);

	return 0;
}

static int kempld_wdt_gettimeout(struct kempld_watchdog_data *wdt,
				 struct kempld_watchdog_stage *stage)
{
	struct kempld_device_data *pld = wdt->pld;
	u8 stage_cfg;
	int bits;
	u64 timeout;
	u32 remainder;

	if (stage == NULL)
		return 0;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_STAGE_CFG(stage->num));

	stage_cfg = kempld_read8(pld, KEMPLD_WDT_STAGE_CFG(stage->num));
	timeout = kempld_read32(pld, KEMPLD_WDT_STAGE_TIMEOUT(stage->num));

	kempld_release_mutex(pld);

	bits = KEMPLD_WDT_STAGE_CFG_GET_PRESCALER(stage_cfg);
	timeout = (timeout & stage->timeout_mask) * KEMPLD_PRESCALER(bits);
	remainder = do_div(timeout, pld->pld_clock);

	/* Round up the return value if necessary */
	if ((timeout > 0) && (remainder >= (pld->pld_clock/2)))
		timeout++;

	return timeout;
}

static int kempld_wdt_setstageaction(struct kempld_watchdog_data *wdt,
				 struct kempld_watchdog_stage *stage,
				 int action)
{
	struct kempld_device_data *pld = wdt->pld;
	u8 stage_cfg;

	if (stage == NULL)
		return -EINVAL;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_STAGE_CFG(stage->num));

	stage_cfg = kempld_read8(pld, KEMPLD_WDT_STAGE_CFG(stage->num));
	stage_cfg &= ~KEMPLD_WDT_STAGE_CFG_ACTION_MASK;
	stage_cfg |= (action & KEMPLD_WDT_STAGE_CFG_ACTION_MASK);
	if (action == KEMPLD_WDT_ACTION_RESET)
		stage_cfg |= KEMPLD_WDT_STAGE_CFG_ASSERT;
	else
		stage_cfg &= ~KEMPLD_WDT_STAGE_CFG_ASSERT;

	kempld_write8(pld, KEMPLD_WDT_STAGE_CFG(stage->num), stage_cfg);

	kempld_release_mutex(pld);

	return 0;
}

static int kempld_wdt_setstagetimeout(struct kempld_watchdog_data *wdt,
				 struct kempld_watchdog_stage *stage,
				 int timeout)
{
	struct kempld_device_data *pld = wdt->pld;
	u8 stage_cfg;
	u8 prescaler;
	u64 stage_timeout64;
	u32 stage_timeout;
	u32 remainder;

	if (stage == NULL)
		return -EINVAL;

	prescaler = KEMPLD_WDT_PRESCALER_21BIT;

	stage_timeout64 = ((u64)timeout*pld->pld_clock);
	remainder = do_div(stage_timeout64, KEMPLD_PRESCALER(prescaler));
	if (remainder)
		stage_timeout64++;
	stage_timeout = stage_timeout64 & stage->timeout_mask;

	if (stage_timeout64 != (u64)stage_timeout)
		return -EINVAL;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_STAGE_CFG(stage->num));

	stage_cfg = kempld_read8(pld, KEMPLD_WDT_STAGE_CFG(stage->num));
	stage_cfg &= ~KEMPLD_WDT_STAGE_CFG_PRESCALER_MASK;
	stage_cfg |= KEMPLD_WDT_STAGE_CFG_SET_PRESCALER(prescaler);
	kempld_write8(pld, KEMPLD_WDT_STAGE_CFG(stage->num), stage_cfg);
	kempld_write32(pld, KEMPLD_WDT_STAGE_TIMEOUT(stage->num),
		       stage_timeout);

	kempld_release_mutex(pld);

	return 0;
}

static void kempld_wdt_update_timeouts(struct kempld_watchdog_data *wdt)
{
	int pretimeout_stage;
	int timeout_stage;

	pretimeout_stage = kempld_wdt_gettimeout(wdt, wdt->pretimeout_stage);
	timeout_stage = kempld_wdt_gettimeout(wdt, wdt->timeout_stage);

	if (pretimeout_stage)
		wdt->pretimeout = timeout_stage;
	else
		wdt->pretimeout = 0;

	wdt->timeout = pretimeout_stage + timeout_stage;

	if (wdt->pretimeout < 0) {
		wdt->pretimeout = WATCHDOG_DEFAULT_PRETIMEOUT;
		dev_err(wdt->pld->dev, "failed to get valid pretimeout value\n"
			" -> using driver default\n");
	}
	if (wdt->timeout < 0) {
		wdt->timeout = WATCHDOG_DEFAULT_TIMEOUT;
		dev_err(wdt->pld->dev, "failed to get valid timeout value\n"
			" -> using driver default\n");
	}
}

static int kempld_wdt_settimeout(struct kempld_watchdog_data *wdt)
{
	int stage_timeout;
	int stage_pretimeout;
	int stage_pretimeout_action;
	int ret = 0;

	if ((wdt->timeout <= 0) ||
	    (wdt->pretimeout < 0) ||
	    (wdt->pretimeout > wdt->timeout)) {
		ret = -EINVAL;
		goto err_check_values;
	}

	if ((wdt->pretimeout == 0) || (wdt->pretimeout_stage == NULL)) {
		if (wdt->pretimeout != 0)
			dev_warn(wdt->pld->dev,
				 "no pretimeout stage available\n"
				 " -> only enabling reset\n");
		stage_pretimeout = 0;
		stage_pretimeout_action = KEMPLD_WDT_ACTION_NONE;
		stage_timeout =  wdt->timeout;
	} else {
		stage_pretimeout = wdt->timeout - wdt->pretimeout;
		stage_timeout =  wdt->pretimeout;
		stage_pretimeout_action = KEMPLD_WDT_ACTION_NMI;
	}

	if (wdt->pretimeout_stage != NULL) {
		ret = kempld_wdt_setstageaction(wdt, wdt->pretimeout_stage,
						stage_pretimeout_action);
		if (ret)
			goto err_setstage;
		ret = kempld_wdt_setstagetimeout(wdt, wdt->pretimeout_stage,
						 stage_pretimeout);
		if (ret)
			goto err_setstage;
	}

	ret = kempld_wdt_setstageaction(wdt, wdt->timeout_stage,
					KEMPLD_WDT_ACTION_RESET);
	if (ret)
		goto err_setstage;
	ret = kempld_wdt_setstagetimeout(wdt, wdt->timeout_stage,
					 stage_timeout);
	if (ret)
		goto err_setstage;

	return 0;
err_setstage:
err_check_values:
	return ret;
}

static ssize_t kempld_wdt_write(struct file *file, const char __user *data,
				size_t count, loff_t *ppos)
{
	struct kempld_watchdog_data *wdt = kempld_wdt;

	BUG_ON(wdt == NULL);

	if (count) {
		kempld_wdt_keepalive(wdt);

		if (!nowayout) {
			size_t i;

			wdt->expect_close = 0;

			for (i = 0; i < count; i++) {
				char c;

				if (get_user(c, data+i))
					return -EFAULT;
				if (c == 'V')
					wdt->expect_close = 42;
			}
		}
	}

	return count;
}

static long kempld_wdt_ioctl(struct file *file, unsigned int cmd,
			     unsigned long arg)
{
	void __user *argp = (void __user *)arg;
	int __user *p = argp;
	struct kempld_watchdog_data *wdt = kempld_wdt;
	int options;
	int value;
	int old_value;
	int ret = 0;

	BUG_ON(wdt == NULL);

	switch (cmd) {
	case WDIOC_GETSUPPORT:
		if (copy_to_user(argp, &wdt->ident, sizeof(wdt->ident)))
			ret = -EFAULT;
		break;
	case WDIOC_GETSTATUS:
	case WDIOC_GETBOOTSTATUS:
		ret = put_user(0, p);
		break;
	case WDIOC_SETOPTIONS:
		if (get_user(options, p)) {
			ret = -EFAULT;
			break;
		}
		if (options & WDIOS_DISABLECARD)
			ret = kempld_wdt_stop(wdt);
		if (options & WDIOS_ENABLECARD) {
			ret = kempld_wdt_start(wdt);
			kempld_wdt_keepalive(wdt);
		}
		break;
	case WDIOC_KEEPALIVE:
		kempld_wdt_keepalive(wdt);
		break;
	case WDIOC_SETTIMEOUT:
		if (get_user(value, p)) {
			ret = -EFAULT;
			break;
		}
		old_value = wdt->timeout;
		wdt->timeout = value;
		ret = kempld_wdt_settimeout(wdt);
		if (ret)
			wdt->timeout = old_value;
		kempld_wdt_keepalive(wdt);
		break;
	case WDIOC_GETTIMEOUT:
		value = kempld_wdt_gettimeout(wdt, wdt->timeout_stage);
		value += kempld_wdt_gettimeout(wdt, wdt->pretimeout_stage);
		if (value < 0)
			ret = ERANGE;
		else
			ret = put_user(value, p);
		break;
	case WDIOC_SETPRETIMEOUT:
		if (get_user(value, p)) {
			ret = -EFAULT;
			break;
		}
		old_value = wdt->pretimeout;
		wdt->pretimeout = value;
		ret = kempld_wdt_settimeout(wdt);
		if (ret)
			wdt->pretimeout = old_value;
		kempld_wdt_keepalive(wdt);
		break;
	case WDIOC_GETPRETIMEOUT:
		value = kempld_wdt_gettimeout(wdt, wdt->pretimeout_stage);
		if (value)
			value = kempld_wdt_gettimeout(wdt, wdt->timeout_stage);
		if (value < 0)
			ret = ERANGE;
		else
			ret = put_user(value, p);
		break;
	default:
		ret = -ENOTTY;
	}

	return ret;
}

static int kempld_wdt_release(struct inode *inode, struct file *file)
{
	struct kempld_watchdog_data *wdt = kempld_wdt;

	BUG_ON(wdt == NULL);

	if (wdt->expect_close)
		kempld_wdt_stop(wdt);
	else {
		dev_warn(wdt->pld->dev,
			 "Unexpected close, not stopping watchdog!\n");
		kempld_wdt_keepalive(wdt);
	}

	kempld_wdt->expect_close = 0;

	clear_bit(0, &wdt->is_open);

	return 0;
}

static int kempld_wdt_open(struct inode *inode, struct file *file)
{
	int ret;
	struct kempld_watchdog_data *wdt = kempld_wdt;
	struct kempld_device_data *pld = wdt->pld;
	u8 status;

	BUG_ON(wdt == NULL);

	if (test_and_set_bit(0, &wdt->is_open))
		return -EBUSY;

	if (nowayout)
		__module_get(THIS_MODULE);

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_CFG);
	status = kempld_read8(pld, KEMPLD_WDT_CFG);
	kempld_release_mutex(pld);

	/* kick the watchdog if it is already enabled, otherwise start it */
	if (status & KEMPLD_WDT_CFG_ENABLE) {
		kempld_wdt_keepalive(wdt);
	} else {
		ret = kempld_wdt_settimeout(wdt);
		if (ret)
			goto err_enable_wdt;
		ret = kempld_wdt_start(wdt);
		if (ret)
			goto err_enable_wdt;
	}

	return nonseekable_open(inode, file);

err_enable_wdt:
	dev_err(wdt->pld->dev, "Failed to enable the watchdog timer!\n");
	wdt->expect_close = 1;
	kempld_wdt_release(inode, file);

	return ret;
}

static void kempld_wdt_release_stages(struct kempld_watchdog_data *wdt)
{
	int stage;

	wdt->timeout_stage = NULL;
	wdt->pretimeout_stage = NULL;

	for (stage = 0; stage < KEMPLD_WDT_MAX_STAGES; stage++) {
		kfree(wdt->stage[stage]);
		wdt->stage[stage] = NULL;
	}
}

static int kempld_wdt_probe_stages(struct kempld_watchdog_data *wdt)
{
	struct kempld_device_data *pld = wdt->pld;
	int i, ret;
	u32 timeout_mask;
	struct kempld_watchdog_stage *stage;

	wdt->stages = 0;
	wdt->timeout_stage = NULL;
	wdt->pretimeout_stage = NULL;

	for (i = 0; i < KEMPLD_WDT_MAX_STAGES; i++) {
		int j;
		u8 index, data, data_orig;

		index = KEMPLD_WDT_STAGE_TIMEOUT(i);
		timeout_mask = ~0;

		kempld_get_mutex_set_index(pld, index);

		/* Probe each byte individually according to new spec revision.
		 * Register content is restored afterwards. */
		for (j = 0; j < 4; j++) {
			data_orig = kempld_read8(pld, index);
			kempld_write8(pld, index, 0x00);
			data = kempld_read8(pld, index);
			kempld_write8(pld, index, data_orig);
			*(((u8 *)&timeout_mask)+j) &= data;
			if (data != 0x0)
				break;
			index++;
		}

		kempld_release_mutex(pld);

		if ((timeout_mask & 0xff) != 0xff) {
			stage = kzalloc(sizeof(struct kempld_watchdog_stage),
					GFP_KERNEL);
			if (stage == NULL) {
				ret = -ENOMEM;
				goto err_alloc_stages;
			}
			stage->num = i;
			stage->timeout_mask = ~timeout_mask;
			wdt->stage[i] = stage;
			wdt->stages++;

			/* assign available stages to timeout and pretimeout */
			if (wdt->timeout_stage == NULL) {
				wdt->timeout_stage = stage;
			} else if ((wdt->pretimeout_stage == NULL) &&
				(pld->feature_mask & KEMPLD_FEATURE_BIT_NMI)) {
				wdt->pretimeout_stage = wdt->timeout_stage;
				wdt->timeout_stage = stage;
			}
		} else
			wdt->stage[i] = NULL;
	}

	return 0;

err_alloc_stages:
	kempld_wdt_release_stages(wdt);

	return ret;
}

static const struct file_operations kempld_wdt_fops = {
	.owner		= THIS_MODULE,
	.llseek		= no_llseek,
	.write		= kempld_wdt_write,
	.unlocked_ioctl	= kempld_wdt_ioctl,
	.open		= kempld_wdt_open,
	.release	= kempld_wdt_release,
};

static struct miscdevice kempld_wdt_miscdev = {
	.minor	= WATCHDOG_MINOR,
	.name	= "watchdog",
	.fops	= &kempld_wdt_fops,
};

static int kempld_wdt_probe(struct platform_device *pdev)
{
	struct kempld_watchdog_data *wdt;
	struct kempld_device_data *pld;
	u8 status;
	int ret;

	if (kempld_wdt != NULL) {
		dev_err(&pdev->dev,
			"unable to support more than one watchdog devices\n");
		return -EMFILE;
	}

	wdt = kzalloc(sizeof(struct kempld_watchdog_data), GFP_KERNEL);
	if (wdt == NULL) {
		ret = -ENOMEM;
		goto err_alloc_dev_data;
	}

	pld = dev_get_drvdata(pdev->dev.parent);
	wdt->pld = pld;

	platform_set_drvdata(pdev, wdt);

	strncpy(wdt->ident.identity, "KEMPLD Watchdog",
		sizeof(wdt->ident.identity));

	/* watchdog firmware version is identical to the CPLD version */
	wdt->ident.firmware_version = (pld->info.major<<24)
		| (pld->info.minor<<16) | pld->info.buildnr;

	/* probe how many usable stages we have */
	ret = kempld_wdt_probe_stages(wdt);
	if (ret)
		goto err_probe_stages;

	/* get initial watchdog status */
	kempld_get_mutex_set_index(pld, KEMPLD_WDT_CFG);
	status = kempld_read8(pld, KEMPLD_WDT_CFG);
	kempld_release_mutex(wdt->pld);

	/* check if the watchdog is already locked and enable the nowayout
	 * option in that case */
	if (status & (KEMPLD_WDT_CFG_ENABLE_LOCK |
		      KEMPLD_WDT_CFG_GLOBAL_LOCK)) {
		if (!nowayout)
			dev_warn(wdt->pld->dev,
				 "Forcing nowayout - watchdog lock enabled!\n");
		nowayout = 1;
	}

	/* set default values for the case we start the watchdog or change
	 * the configuration */
	wdt->timeout = WATCHDOG_DEFAULT_TIMEOUT;
	wdt->pretimeout = WATCHDOG_DEFAULT_PRETIMEOUT;

	/* check if watchdog is enabled */
	if (status & KEMPLD_WDT_CFG_ENABLE) {
		/* Get current watchdog settings */
		kempld_wdt_update_timeouts(wdt);

		dev_info(wdt->pld->dev, "Watchdog is already enabled:\n"
			 "%d s timeout and %d s pretimeout!\n",
			 wdt->timeout, wdt->pretimeout);
	}

	/* update the timeout settings if requested by module parameters */
	if (timeout > 0)
		wdt->timeout = timeout;
	if (pretimeout >= 0)
		wdt->pretimeout = pretimeout;

	dev_info(wdt->pld->dev, "watchdog will be set on (re)start\n"
		 "new settings: %d s timeout and %d s pretimeout\n",
		 wdt->timeout, wdt->pretimeout);

	wdt->ident.options = WDIOF_KEEPALIVEPING;
	if ((wdt->timeout_stage) && !(status & KEMPLD_WDT_CFG_GLOBAL_LOCK))
		wdt->ident.options |= WDIOF_SETTIMEOUT;
	if (wdt->pretimeout_stage)
		wdt->ident.options |= WDIOF_PRETIMEOUT;
	if (!nowayout)
		wdt->ident.options |= WDIOF_MAGICCLOSE;

	kempld_wdt = wdt;

	ret = misc_register(&kempld_wdt_miscdev);
	if (ret)
		goto err_misc_register;

	dev_info(wdt->pld->dev,
		 "%d stage watchdog initialized, pretimeout %ssupported\n",
		 wdt->stages, wdt->pretimeout_stage ? "" : "not ");

	return 0;

err_probe_stages:
err_misc_register:
	kfree(kempld_wdt);
	kempld_wdt = NULL;
err_alloc_dev_data:
	return ret;
}

static void kempld_wdt_shutdown(struct platform_device *pdev)
{
	struct kempld_watchdog_data *wdt = platform_get_drvdata(pdev);

	BUG_ON(wdt != kempld_wdt);

	/* stop or at least keepalive the watchdog before we leave */
	if (wdt != NULL) {
		if (!nowayout)
			kempld_wdt_stop(wdt);
		else
			kempld_wdt_keepalive(wdt);
	}
}

static int kempld_wdt_remove(struct platform_device *pdev)
{
	struct kempld_watchdog_data *wdt = platform_get_drvdata(pdev);

	BUG_ON(wdt != kempld_wdt);

	/* stop or at least keepalive the watchdog before we leave */
	kempld_wdt_shutdown(pdev);

	misc_deregister(&kempld_wdt_miscdev);

	kempld_wdt_release_stages(wdt);

	kfree(wdt);
	kempld_wdt = NULL;
	platform_set_drvdata(pdev, NULL);

	return 0;
}

#ifdef CONFIG_PM_SLEEP
static int wdt_pm_status_store;

/* Disable watchdog if it is active during suspend */
static int kempld_wdt_suspend(struct device *dev)
{
	struct platform_device *pdev = to_platform_device(dev);
	struct kempld_watchdog_data *wdt = dev_get_drvdata(dev);
	struct kempld_device_data *pld = wdt->pld;

	kempld_get_mutex_set_index(pld, KEMPLD_WDT_CFG);
	wdt_pm_status_store = kempld_read8(pld, KEMPLD_WDT_CFG);
	kempld_release_mutex(pld);

	if (wdt_pm_status_store & KEMPLD_WDT_CFG_ENABLE) {
		kempld_wdt_update_timeouts(wdt);
		kempld_wdt_shutdown(pdev);
	}

	return 0;
}

/* Enable watchdog and configure it if necessary */
static int kempld_wdt_resume(struct device *dev)
{
	struct platform_device *pdev = to_platform_device(dev);
	struct kempld_watchdog_data *wdt = dev_get_drvdata(dev);
	int ret;

	/* if watchdog was stopped before suspend be sure it gets disabled
	 * again, for the case BIOS has enabled it during resume */
	if (wdt_pm_status_store & KEMPLD_WDT_CFG_ENABLE) {
		ret = kempld_wdt_settimeout(wdt);
		if (ret)
			goto err_enable_wdt;
		ret = kempld_wdt_start(wdt);
		if (ret)
			goto err_enable_wdt;

		dev_info(wdt->pld->dev, "Resuming watchdog operation:\n"
			 "%d s timeout and %d s pretimeout\n", wdt->timeout,
			 wdt->pretimeout);
	} else
		kempld_wdt_shutdown(pdev);

	return 0;

err_enable_wdt:
	dev_err(wdt->pld->dev,
		"Failed to reenable the watchdog timer after resume!\n");

	return ret;
}
#endif

static const struct dev_pm_ops kempld_wdt_pm_ops = {
#ifdef CONFIG_PM_SLEEP
	.suspend = kempld_wdt_suspend,
	.resume = kempld_wdt_resume,
	.poweroff =  kempld_wdt_suspend,
	.restore = kempld_wdt_resume,
#endif
};

static struct platform_driver kempld_wdt_driver = {
	.driver = {
		.name = "kempld-wdt",
		.owner = THIS_MODULE,
		.pm = &kempld_wdt_pm_ops,
	},
	.probe = kempld_wdt_probe,
	.remove = kempld_wdt_remove,
	.shutdown = kempld_wdt_shutdown,
};

static int __init kempld_wdt_init(void)
{
	return platform_driver_register(&kempld_wdt_driver);
}

static void __exit kempld_wdt_exit(void)
{
	platform_driver_unregister(&kempld_wdt_driver);
}

module_init(kempld_wdt_init);
module_exit(kempld_wdt_exit);

MODULE_DESCRIPTION("KEM PLD Watchdog Driver");
MODULE_AUTHOR("Michael Brunner <michael.brunner@kontron.com>");
MODULE_LICENSE("GPL");
MODULE_ALIAS_MISCDEV(WATCHDOG_MINOR);
MODULE_VERSION("34.0");
