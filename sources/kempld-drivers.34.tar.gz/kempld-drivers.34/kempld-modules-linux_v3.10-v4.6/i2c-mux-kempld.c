/*
 *  i2c-mux-kempld.c: I2C bus multiplexer driver for Kontron COM modules
 *
 *  Copyright (c) 2010-2020 Kontron Europe GmbH
 *  Author: Michael Brunner <michael.brunner@kontron.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License 2 as published
 *  by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/platform_device.h>
#include <linux/i2c.h>
#include <linux/i2c-mux.h>
#include <linux/delay.h>
#include <linux/slab.h>
#include "include/linux/mfd/kempld.h"
#include "include/linux/i2c/kempld.h"

/* Some version dependent code to get compatibility with older kernels */
#include <linux/version.h>
#define __NO_VERSION__ /* don't define the kernel version global variable */
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3, 7, 0))
# if (LINUX_VERSION_CODE < KERNEL_VERSION(3, 5, 0))
#  define i2c_add_mux_adapter(a, b, c, d, e, f, g, h) \
	i2c_add_mux_adapter(a, c, d, e, g, h)
# else
#  define i2c_add_mux_adapter(a, b, c, d, e, f, g, h) \
	i2c_add_mux_adapter(a, c, d, e, f, g, h)
# endif
#endif

static bool noeeep;
module_param(noeeep, bool, 0444);
MODULE_PARM_DESC(noeeep, "Skip registering the Kontron EEEP device");

static struct i2c_board_info kontron_eeep_info = {
	I2C_BOARD_INFO("kontron_eeep", 0x50),
};

static int i2c_mux_kempld_select(struct i2c_adapter *adap, void *data,
				 u32 chan)
{
	struct kempld_i2c_data *i2c = data;
	struct kempld_device_data *pld = i2c->pld;
	int ret = 0;

	if ((i2c->state == STATE_DONE) || (i2c->state == STATE_ERROR)) {
		if (i2c->mx != chan) {
			kempld_get_mutex_set_index(pld, KEMPLD_I2C_MX);
			i2c->mx = chan & 0x0f;
			kempld_write8(pld, KEMPLD_I2C_MX, i2c->mx);
			kempld_release_mutex(pld);
		}
	} else
		ret = -EBUSY;

	return ret;
}

static void i2c_mux_kempld_del(struct kempld_i2c_data *i2c)
{
	int i;

	if (!i2c->mux_adap)
		return;

	for (i = 0; i <= i2c->mx_max; i++) {
		if (i2c->mux_adap[i])
			i2c_del_mux_adapter(i2c->mux_adap[i]);
	}

	if (i2c->mux_parent)
		i2c_put_adapter(i2c->mux_parent);
}

unsigned int mux_class[] = {
	0,				 /* 0 default I2C bus */
	I2C_CLASS_DDC,			 /* 1 system/internal and/or
					      DDC I2C bus */
	0,				 /* 2 optional GPIO I2C */
};

static int i2c_mux_kempld_probe(struct platform_device *pdev)
{
	struct device *dev = &pdev->dev;
	struct kempld_i2c_data *i2c = dev_get_platdata(&pdev->dev);
	struct i2c_adapter *parent;
	unsigned int class;
	int i;
	int ret;

	parent = i2c_get_adapter(i2c->adap.nr);
	if (!parent)
		return -EPROBE_DEFER;

	i2c->mux_parent = parent;

	i2c->mux_adap = devm_kzalloc(&pdev->dev,
			     sizeof(*i2c->mux_adap) * (i2c->mx_max + 1),
			     GFP_KERNEL);
	if (!i2c->mux_adap)
		return -ENOMEM;

	for (i = 0; i <= i2c->mx_max; i++) {
		u32 nr = 0;

		if (i2c->base_nr >= 0)
			nr = i2c->base_nr + 1 + i;

		if (i < (sizeof(mux_class) / sizeof(mux_class[0])))
			class = mux_class[i];
		else
			class = 0;

		i2c->mux_adap[i] = devm_kzalloc(&pdev->dev,
						sizeof(**i2c->mux_adap),
						GFP_KERNEL);
		if (!i2c->mux_adap[i]) {
			ret = -ENOMEM;
			goto add_mux_adapter_failed;
		}

		i2c->mux_adap[i] = i2c_add_mux_adapter(parent, dev,
						     i2c, nr, i, class,
						     i2c_mux_kempld_select,
						     NULL);
		if (!i2c->mux_adap[i]) {
			ret = -ENODEV;
			dev_err(dev, "Failed to register MUX adapter %d\n", i);
			goto add_mux_adapter_failed;
		}
	}

	/* Register Kontron EEEP device which is on channel 0 addr 0x50 */
	if (!noeeep)
		i2c_new_device(i2c->mux_adap[0], &kontron_eeep_info);

	return 0;

add_mux_adapter_failed:
	i2c_mux_kempld_del(i2c);

	return ret;
}

static int i2c_mux_kempld_remove(struct platform_device *pdev)
{
	struct kempld_i2c_data *i2c = dev_get_platdata(&pdev->dev);

	i2c_mux_kempld_del(i2c);

	return 0;
}

static struct platform_driver i2c_mux_kempld_driver = {
	.driver = {
		.name = "i2c-mux-kempld",
		.owner = THIS_MODULE,
	},
	.probe		= i2c_mux_kempld_probe,
	.remove		= i2c_mux_kempld_remove,
};

static int __init i2c_mux_kempld_init(void)
{
	return platform_driver_register(&i2c_mux_kempld_driver);
}

static void __exit i2c_mux_kempld_exit(void)
{
	platform_driver_unregister(&i2c_mux_kempld_driver);
}

module_init(i2c_mux_kempld_init);
module_exit(i2c_mux_kempld_exit);

MODULE_DESCRIPTION("KEM PLD I2C multiplexer driver");
MODULE_AUTHOR("Michael Brunner <michael.brunner@kontron.com>");
MODULE_LICENSE("GPL");
MODULE_ALIAS("platform:i2c-mux-kempld");
MODULE_VERSION("34.0");
