// SPDX-License-Identifier: GPL-2.0-only
/*
 *  kontron_bl.c - Kontron Universal Backlight Driver.
 *  Based on driver for Sharp SL-6000x
 *
 *  Driver supports KAB-ADAPT-LVDS adapter and PWM control for various Kontron
 *  boards
 *
 *  Copyright (c) 2012-2013 Kontron
 *  Author: Viktor Krasnov <vkrasnov@dev.rtsoft.ru>
 *          Andrey Rusalin <arusalin@dev.rtsot.ru>
 *
 *  Copyright (c) 2013-2014 Kontron Europe GmbH
 *  Michael Brunner <michael.brunner@kontron.com>
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/mutex.h>
#include <linux/fb.h>
#include <linux/backlight.h>
#include <linux/dmi.h>
#include <linux/i2c.h>
#include <linux/platform_device.h>
#include <linux/pci.h>

#define KU_MAX_BACKLIGHT	100
#define DRV_PFX			"ku_backlight: "
#define PWM_INIT_ERROR		"Initializing of backlight PWM control\n"
#define BLC_PWM_CTL2_OFFSET	0x61250
#define BLC_PWM_CTL_OFFSET	0x61254
#define MMADR_OFFSET		0x10

#define BACKLIGHT_INFO_DMI_DEV_TYPE 162

enum devices { ku_i2c_backlight, ku_i2c_backlight_ext };

/*
 * If force is set to anything different from 0, we forcibly enable the
 * backlight. DANGEROUS!
 */
static int force_bl_type;
module_param(force_bl_type, int, 0444);
MODULE_PARM_DESC(force_bl_type, "Forcibly selecting backlight mode");

static bool enable_ext_bl;
module_param(enable_ext_bl, bool, 0444);
MODULE_PARM_DESC(enable_ext_bl, "Enable ext backlight support");

static const struct dmi_system_id supported_boards_dmi_table[] = {
	{
		.ident = "COME",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-"),
		},
	},
	{
		.ident = "SMARC",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "SMARC-"),
		},
	},
	{
		.ident = "BBL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bBL6"),
		},
	},
	{
		.ident = "BCL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bCL6"),
		},
	},
	{
		.ident = "BKL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bKL6"),
		},
	},
	{
		.ident = "BSL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bSL6"),
		},
	},
	{
		.ident = "CAL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cAL"),
		},
	},
	{
		.ident = "CBL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cBL6"),
		},
	},
	{
		.ident = "CBW6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cBW6"),
		},
	},
	{
		.ident = "CKL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cKL6"),
		},
	},
	{
		.ident = "CVR6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cVR6"),
		},
	},
	{
		.ident = "CVV6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cBT"),
		},
	},
	{
		.ident = "MAL1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mAL"),
		},
	},
	{
		.ident = "MVV1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mBT"),
		},
	},
	{
		.ident = "NTC1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "nanoETXexpress-TT"),
		},
	},
	{
		.ident = "NTC1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "nETXe-TT"),
		},
	},
	{
		.ident = "UUP6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cCT6"),
		},
	},
	{
		.ident = "NUP1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mCT10"),
		},
	},
	{
		.ident = "BHL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bHL6"),
		},
	},
	{
		.ident = "CHL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cHL6"),
		},
	},
	{
		.ident = "CSL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cSL6"),
		},
	},
	{}
};

static int ku_bl_i2c_registered[] = {
	[ku_i2c_backlight] = 0,
	[ku_i2c_backlight_ext] = 0,
};

unsigned int ku_bl_pci_devices[] = {
	0x416, /* Haswell GFX */
	0xBE2, /* Cedarview GFX */
	0x4108, /* Tunnel Creek GFX */
	/*
	 * Devices not supported here should be supported directly by a native
	 * driver (e.g. intel_backlight), the graphics driver or ACPI.
	 */
};

static const unsigned short normal_i2c[] = { 0x31, I2C_CLIENT_END };

enum bltype {
	bltype_none = 0,
	bltype_pwm = 1,
	bltype_i2c = 2,
	bltype_pwm_inv = 5,
	bltype_i2c_inv = 6
};

struct ku_bl_data {
	struct i2c_client *i2c;
	struct platform_device *pdev;
	struct backlight_device *bl;
	u8 backlight_type;
	/*next 3 fields is needed for pwm backlight */
	struct pci_dev *pci_dev;
	void __iomem *pwm_ctl_addr;	/*iomapped PWM_CTL address */
	u32 pwm_high;		/*pwm frequency */
};

static void
ku_bl_i2c_set_backlight(struct ku_bl_data *data, int brightness)
{
	struct i2c_client *i2c = data->i2c;
	/*send backlight value to DAC */
	i2c_smbus_write_byte(i2c, brightness & 0xff);
}

static void
ku_bl_pwm_set_backlight(struct ku_bl_data *data, int brightness)
{
	/*calculate pwm value and write it */
	/*u32 pwm_val = ((data->pwm_high >> 16) * (0xFF - brightness)) / 0xFF;*/
	u32 pwm_val = ((data->pwm_high >> 16) * brightness) / 0xFF;

	iowrite32(data->pwm_high | pwm_val, data->pwm_ctl_addr);
}

static int
ku_bl_update_status(struct backlight_device *dev)
{
	struct backlight_properties *props = &dev->props;
	struct ku_bl_data *data = dev_get_drvdata(&dev->dev);
	int brightness = props->brightness;

	if ((data->backlight_type == bltype_i2c_inv)
	    || (data->backlight_type == bltype_pwm_inv))
		brightness = 255 - (brightness * 255) / 100;
	else
		brightness = (brightness * 255) / 100;

	if ((data->backlight_type == bltype_i2c)
	    || (data->backlight_type == bltype_i2c_inv))
		ku_bl_i2c_set_backlight(data, brightness);
	else
		ku_bl_pwm_set_backlight(data, brightness);

	return 0;
}

static int
ku_bl_get_brightness(struct backlight_device *dev)
{
	struct backlight_properties *props = &dev->props;

	return props->brightness;
}

static const struct backlight_ops ku_bl_ops = {
	.get_brightness = ku_bl_get_brightness,
	.update_status = ku_bl_update_status,
};

#ifdef CONFIG_PM_SLEEP
static int
ku_bl_i2c_suspend(struct device *dev)
{
	struct i2c_client *client = to_i2c_client(dev);
	struct ku_bl_data *data = i2c_get_clientdata(client);

	ku_bl_i2c_set_backlight(data, 0);

	return 0;
}

static int
ku_bl_i2c_resume(struct device *dev)
{
	struct i2c_client *client = to_i2c_client(dev);
	struct ku_bl_data *data = i2c_get_clientdata(client);

	ku_bl_update_status(data->bl);

	return 0;
}

static int
ku_bl_pwm_suspend(struct device *dev)
{
	struct backlight_device *bl = dev_get_drvdata(dev);
	struct ku_bl_data *data = bl_get_data(bl);

	ku_bl_pwm_set_backlight(data, 0);

	return 0;
}

static int
ku_bl_pwm_resume(struct device *dev)
{
	struct backlight_device *bl = dev_get_drvdata(dev);
	struct ku_bl_data *data = bl_get_data(bl);

	ku_bl_update_status(data->bl);

	return 0;
}
#endif

static const struct dev_pm_ops ku_bl_i2c_pm_ops = {
#ifdef CONFIG_PM_SLEEP
	.suspend = ku_bl_i2c_suspend,
	.resume = ku_bl_i2c_resume,
	.poweroff = ku_bl_i2c_suspend,
	.restore = ku_bl_i2c_resume,
#endif
};

static const struct dev_pm_ops ku_bl_pwm_pm_ops = {
#ifdef CONFIG_PM_SLEEP
	.suspend = ku_bl_pwm_suspend,
	.resume = ku_bl_pwm_resume,
	.poweroff = ku_bl_pwm_suspend,
	.restore = ku_bl_pwm_resume,
#endif
};

static int
ku_bl_i2c_detect(struct i2c_client *client, struct i2c_board_info *info)
{
	struct i2c_adapter *adapter = client->adapter;
	int address = client->addr;
	const char *name = NULL;

	if (!i2c_check_functionality(adapter, I2C_FUNC_SMBUS_WRITE_BYTE))
		return -ENODEV;

	if (strcmp(adapter->name, "dmdc") == 0)
		return -ENODEV;

	if ((address == 0x31) &&
	    ((strcmp(adapter->name, "i915 gmbus panel") == 0)
	     || (strcmp(adapter->name, "intel drm LVDSDDC_C") == 0)
	     || ((strncmp(adapter->name, "i2c-", 3) == 0) &&
		 ((strstr(adapter->name, "-mux(chan_id 1)") == 0)
		  || (strstr(adapter->name, "-mux (chan_id 1)") == 0))))) {
		name = "i2c_backlight";
		dev_info(&client->adapter->dev,
			 "I2C backlight device found on %s at 0x%02x\n",
			 adapter->name, address);
	} else if ((address == 0x31) &&
	    ((strcmp(adapter->name, "DPDDC-B") == 0) ||
	     (strcmp(adapter->name, "DPDDC-C") == 0) ||
	     (strcmp(adapter->name, "DPDDC-D") == 0))) {
		if (!enable_ext_bl) {
			dev_info(&client->adapter->dev,
				 "Ext. backlight device on %s at 0x%02x ignored\n",
				 adapter->name, address);
			return -ENODEV;
		}
		dev_info(&client->adapter->dev,
			 "Ext. I2C backlight device found on %s at 0x%02x\n",
			 adapter->name, address);
		name = "i2c_backlight_ext";
	} else {
		dev_info(&client->adapter->dev,
			 "Unsupported chip on %s at 0x%02x\n",
			 adapter->name, address);
		return -ENODEV;
	}

	strlcpy(info->type, name, I2C_NAME_SIZE);

	return 0;
}

struct dmi_backlight_found {
	u8 type;
	u8 brightness;
	int found;
};

void
dmi_decode_backlight_info(const struct dmi_header *dmih, void *pdata)
{
	struct dmi_backlight_found *dmi_bl_found = pdata;

	struct dmi_kem_backlight_info {
		const struct dmi_header header;
		u8 kemid[4];
		u8 struct_rev;
		u8 backlight_type;
		u8 backlight_value;
		u8 reserved;
		u32 pwm_freq;
	} *dmi_bl_inf;

	if (dmih->type == BACKLIGHT_INFO_DMI_DEV_TYPE) {
		dmi_bl_inf = (struct dmi_kem_backlight_info *) dmih;
		dmi_bl_found->type = dmi_bl_inf->backlight_type;
		dmi_bl_found->found = 1;
		if (dmi_bl_inf->backlight_type == bltype_i2c
		    || dmi_bl_inf->backlight_type == bltype_pwm) {
			dmi_bl_found->brightness = dmi_bl_inf->backlight_value;
			dmi_bl_found->found = 1;
		} else if (dmi_bl_inf->backlight_type == bltype_i2c_inv
			   || dmi_bl_inf->backlight_type == bltype_pwm_inv) {
			dmi_bl_found->brightness =
			    255 - dmi_bl_inf->backlight_value;
			dmi_bl_found->found = 1;
		}
	}
}

static int ku_bl_i2c_probe(struct i2c_client *client,
		       const struct i2c_device_id *id)
{
	struct dmi_backlight_found dmi_bl_found = {0};
	struct backlight_properties props;
	struct ku_bl_data *data;
	int bl_device_id;
	char *devname;
	int ret;

	if (id->driver_data == ku_i2c_backlight) {
		devname = "ku_backlight";
		bl_device_id = ku_i2c_backlight;
	} else {
		devname = "ku_backlight_ext";
		bl_device_id = ku_i2c_backlight_ext;
	}

	if (ku_bl_i2c_registered[bl_device_id]) {
		dev_warn(&client->dev, "Device name %s already registered\n",
			 devname);
		return -EEXIST;
	}

	data = kzalloc(sizeof(struct ku_bl_data), GFP_KERNEL);
	if (!data)
		return -ENOMEM;

	i2c_set_clientdata(client, data);
	data->i2c = client;

	memset(&props, 0, sizeof(struct backlight_properties));
	props.max_brightness = KU_MAX_BACKLIGHT;
	props.type = BACKLIGHT_RAW;

	data->bl = backlight_device_register(devname, &client->dev, data,
					     &ku_bl_ops, &props);
	if (IS_ERR(data->bl))
		return PTR_ERR(data->bl);

	ku_bl_i2c_registered[bl_device_id] = 1;

	data->backlight_type = force_bl_type;
	ret = dmi_walk(dmi_decode_backlight_info, &dmi_bl_found);
	if (ret)
		dev_err(&client->dev, "unable to walk DMI table\n");

	if (dmi_bl_found.found)
		data->bl->props.brightness =
		    (dmi_bl_found.brightness * 100) / 255;
	else
		data->bl->props.brightness = KU_MAX_BACKLIGHT;

	ku_bl_update_status(data->bl);

	dev_info(&client->dev, "Registered I2C backlight device");

	return 0;
}

static int ku_bl_i2c_remove(struct i2c_client *client)
{
	struct ku_bl_data *data = i2c_get_clientdata(client);

	backlight_device_unregister(data->bl);
	data->bl = NULL;

	kfree(data);

	return 0;
}

static const struct i2c_device_id ku_bl_i2c_id[] = {
	{"i2c_backlight", ku_i2c_backlight},
	{"i2c_backlight_ext", ku_i2c_backlight_ext},
	{},
};

MODULE_DEVICE_TABLE(i2c, ku_bl_i2c_id);

static struct i2c_driver ku_bl_i2c_driver = {
	.class = I2C_CLASS_DDC,
	.driver = {
		   .name = "ku_i2c_backlight",
		   .owner = THIS_MODULE,
		   .pm = &ku_bl_i2c_pm_ops,
		   },
	.probe = ku_bl_i2c_probe,
	.remove = ku_bl_i2c_remove,
	.id_table = ku_bl_i2c_id,
	.detect = ku_bl_i2c_detect,
	.address_list = normal_i2c,
};

static int
ku_bl_pwm_probe(struct platform_device *pdev)
{
	struct backlight_properties props;
	struct dmi_backlight_found dmi_bl_found;
	u32 mmadr, temp_val;
	void __iomem *pwm_ctl2_addr;
	int ret;
	struct ku_bl_data *data;
	unsigned int id;

	data = kzalloc(sizeof(struct ku_bl_data), GFP_KERNEL);
	if (!data)
		return -ENOMEM;

	platform_set_drvdata(pdev, data);
	data->pdev = pdev;

	/*trying to initialize pwm backlight control */
	/*search pci dev, Intel CedarView GFX */
	for (id = 0; id < ARRAY_SIZE(ku_bl_pci_devices); id++) {
		data->pci_dev = pci_get_device(PCI_VENDOR_ID_INTEL,
					       ku_bl_pci_devices[id], NULL);
		if (data->pci_dev)
			break;
	}
	if (!data->pci_dev) {
		dev_warn(&data->pdev->dev, "Not supported for this device\n");
		goto exit0;
	} else {
		ret =
		    pci_read_config_dword(data->pci_dev, MMADR_OFFSET, &mmadr);
		if (ret)
			goto exit1;
		else {
			data->pwm_ctl_addr =
			    ioremap(mmadr + BLC_PWM_CTL_OFFSET, sizeof(u32));
			pwm_ctl2_addr =
			    ioremap(mmadr + BLC_PWM_CTL2_OFFSET, sizeof(u32));
			if (!data->pwm_ctl_addr || !pwm_ctl2_addr) {
				iounmap(data->pwm_ctl_addr);
				iounmap(pwm_ctl2_addr);
				goto exit1;
			} else {
				temp_val = ioread32(pwm_ctl2_addr);
				iowrite32((temp_val & 0xBFFFFFFF) | 0xA0000000,
					  pwm_ctl2_addr);
				temp_val = ioread32(data->pwm_ctl_addr);
				data->pwm_high = temp_val & 0xFFFF0000;
			}
		}
	}

	memset(&props, 0, sizeof(struct backlight_properties));
	props.max_brightness = KU_MAX_BACKLIGHT;
	props.type = BACKLIGHT_RAW;
	data->bl = backlight_device_register("ku_pwm_backlight", &pdev->dev,
					     data, &ku_bl_ops, &props);
	if (IS_ERR(data->bl))
		goto exit1;

	data->backlight_type = force_bl_type;
	dmi_walk(dmi_decode_backlight_info, &dmi_bl_found);
	if (dmi_bl_found.found)
		data->bl->props.brightness =
		    (dmi_bl_found.brightness * 100) / 255;
	else
		data->bl->props.brightness = KU_MAX_BACKLIGHT;

	ku_bl_update_status(data->bl);

	dev_info(&pdev->dev, "Registered PWM backlight device");

	return 0;

exit1:
	pci_dev_put(data->pci_dev);
exit0:
	kfree(data);
	dev_warn(&pdev->dev, PWM_INIT_ERROR);
	return -ENODEV;
}

static int
ku_bl_pwm_remove(struct platform_device *pdev)
{
	struct ku_bl_data *data = platform_get_drvdata(pdev);

	backlight_device_unregister(data->bl);
	data->bl = NULL;
	iounmap(data->pwm_ctl_addr);
	pci_dev_put(data->pci_dev);
	kfree(data);

	return 0;
}

static struct platform_driver ku_bl_pwm_driver = {
	.probe = ku_bl_pwm_probe,
	.remove = ku_bl_pwm_remove,
	.driver = {
		   .owner = THIS_MODULE,
		   .name = "ku_pwm_backlight",
		   .pm = &ku_bl_pwm_pm_ops,
		   },
};

static struct platform_device *ku_backlight_dev;

static int __init ku_bl_init(void)
{
	int ret;

	struct dmi_backlight_found dmi_bl_found = {0};

	if (!dmi_check_system(supported_boards_dmi_table)) {
		if (force_bl_type != 0)
			pr_warn(DRV_PFX
				"No device detected - forcing driver load!");
		else
			return -ENODEV;
	}

	if (force_bl_type == 0) {
		ret = dmi_walk(dmi_decode_backlight_info, &dmi_bl_found);
		if (ret) {
			pr_err(DRV_PFX "unable to walk DMI table\n");
			return -ENXIO;
		}
		if (dmi_bl_found.found)
			force_bl_type = dmi_bl_found.type;
		else
			return -ENODEV;
	}

	if ((force_bl_type == bltype_i2c)
	    || (force_bl_type == bltype_i2c_inv)) {
		return i2c_add_driver(&ku_bl_i2c_driver);
	} else if ((force_bl_type == bltype_pwm)
		 || (force_bl_type == bltype_pwm_inv)) {
		ret = platform_driver_register(&ku_bl_pwm_driver);
		if (ret)
			return ret;

		ku_backlight_dev =
		    platform_device_register_simple("ku_pwm_backlight", -1,
						    NULL, 0);
		if (IS_ERR(ku_backlight_dev)) {
			platform_driver_unregister(&ku_bl_pwm_driver);
			return PTR_ERR(ku_backlight_dev);
		}
		return 0;
	}

	return -ENODEV;
}

static void __exit ku_bl_exit(void)
{
	if ((force_bl_type == bltype_i2c)
	    || (force_bl_type == bltype_i2c_inv)) {
		i2c_del_driver(&ku_bl_i2c_driver);
	} else if ((force_bl_type == bltype_pwm)
		 || (force_bl_type == bltype_pwm_inv)) {
		platform_device_unregister(ku_backlight_dev);
		platform_driver_unregister(&ku_bl_pwm_driver);
	}
}

module_init(ku_bl_init);
module_exit(ku_bl_exit);

MODULE_AUTHOR("Viktor Krasnov <vkrasnov@dev.rtsoft.ru>");
MODULE_DESCRIPTION("Kontron Universal Backlight Driver");
MODULE_LICENSE("GPL");
MODULE_ALIAS("backlight:ku_backlight");
MODULE_ALIAS("backlight:kontron_bl");
MODULE_VERSION("11.0");
