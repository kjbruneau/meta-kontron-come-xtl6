// SPDX-License-Identifier: GPL-2.0-only
/*
 * kontron_bootcounter.c - Bootcounter driver for Kontron Modules
 *
 * Based on chr2_bootcounter driver.
 * Author: Viktor Krasnov <vkrasnov@dev@rtsoft.ru>
 *
 * Copyright (C) 2011-2014 Kontron Europe GmbH
 * Author: Michael Brunner <michael.brunner@kontron.com>
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/platform_device.h>
#include <linux/mutex.h>
#include <linux/dmi.h>

#define KONTRON_DMI_ENTRY_SIZE	28
#define KONTRON_BC_SIZE		4

static unsigned int bootcount;

static const struct dmi_system_id kontron_bc_dmi_table[] = {
	{
		.ident = "COME",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-"),
		},
	},
	{
		.ident = "SMARC",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "SMARC-"),
		},
	},
	{
		.ident = "BBD6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bBD6"),
		},
	},
	{
		.ident = "BBD7",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bBD7"),
		},
	},
	{
		.ident = "BBL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bBL6"),
		},
	},
	{
		.ident = "BCL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bCL6"),
		},
	},
	{
		.ident = "BDV7",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bDV7"),
		},
	},
	{
		.ident = "BHL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bHL6"),
		},
	},
	{
		.ident = "BSL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bSL6"),
		},
	},
	{
		.ident = "BKL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-bKL6"),
		},
	},
	{
		.ident = "CAL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cAL"),
		},
	},
	{
		.ident = "CVR6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cVR6"),
		},
	},
	{
		.ident = "CVV6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cBT"),
		},
	},
	{
		.ident = "CBL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cBL6"),
		},
	},
	{
		.ident = "CBW6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cBW6"),
		},
	},
	{
		.ident = "CHL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cHL6"),
		},
	},
	{
		.ident = "CSL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cSL6"),
		},
	},
	{
		.ident = "CKL6",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-cKL6"),
		},
	},
	{
		.ident = "MAL1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mAL"),
		},
	},
	{
		.ident = "MVV1",
		.matches = {
			DMI_MATCH(DMI_BOARD_VENDOR, "Kontron"),
			DMI_MATCH(DMI_BOARD_NAME, "COMe-mBT"),
		},
	},
	{ }
};

static void type_bc_dmi_decode(const struct dmi_header *header, void *dummy)
{

	if (header->type != 161)
		return;

	if (header->length == KONTRON_DMI_ENTRY_SIZE)
		memcpy(dummy, header, KONTRON_DMI_ENTRY_SIZE);
	else
		memset(dummy, 0x00, KONTRON_DMI_ENTRY_SIZE);
}

static ssize_t count_show(struct device *dev,
		struct device_attribute *attr, char *buf)
{
	return sprintf(buf, "%u\n", bootcount);
}

static DEVICE_ATTR(count, 0444, count_show, NULL);

static int kontron_bc_probe(struct platform_device *pdev)
{
	int err, i;
	unsigned char kontron_dmi_entry[KONTRON_DMI_ENTRY_SIZE];

	if (!dmi_check_system(kontron_bc_dmi_table))
		return -ENODEV;


	dmi_walk(type_bc_dmi_decode, kontron_dmi_entry);
	for (i = 0; i < KONTRON_BC_SIZE; i++) {
		bootcount = bootcount << 8;
		bootcount  += kontron_dmi_entry[16+i];
	}

	if (bootcount > 0) {
		dev_info(&pdev->dev, "Boot count: %u\n", bootcount);
	} else {
		dev_err(&pdev->dev, "Unable to get boot count\n");
		return -ENODEV;
	}

	err = device_create_file(&pdev->dev, &dev_attr_count);
	if (err)
		return err;

	return 0;
}

static int kontron_bc_remove(struct platform_device *pdev)
{
	device_remove_file(&pdev->dev, &dev_attr_count);

	return 0;
}

static struct platform_driver kontron_bc_driver = {
	.probe		= kontron_bc_probe,
	.remove		= kontron_bc_remove,
	.driver		= {
		.name	= "kontron-bootcounter",
		.owner  = THIS_MODULE,
	},
};

static struct platform_device *kontron_bc_device;

static int __init kontron_bc_init(void)
{
	int ret;

	ret = platform_driver_register(&kontron_bc_driver);
	if (ret)
		return ret;
	kontron_bc_device =
		platform_device_register_simple("kontron-bootcounter", -1,
						NULL, 0);

	if (IS_ERR(kontron_bc_device)) {
		platform_driver_unregister(&kontron_bc_driver);
		return PTR_ERR(kontron_bc_device);
	}
	return 0;
}

static void __exit kontron_bc_exit(void)
{
	platform_device_unregister(kontron_bc_device);
	platform_driver_unregister(&kontron_bc_driver);
}

module_init(kontron_bc_init);
module_exit(kontron_bc_exit);

MODULE_AUTHOR("Michael Brunner <michael.brunner@kontron.com>");
MODULE_DESCRIPTION("Kontron Bootcounter Driver");
MODULE_LICENSE("GPL");
MODULE_ALIAS("platform:kontron_bootcounter");
MODULE_VERSION("11.0");
