// SPDX-License-Identifier: GPL-2.0-only
/*
 * kontron_eeep.c - Embedded EEPROM driver for Kontron Modules.
 *
 * Based on chr2_eeprom driver.
 * Author: Viktor Krasnov <vkrasnov@dev@rtsoft.ru>
 *
 * Copyright (C) 2011-2014 Kontron Europe GmbH
 * Michael Brunner <michael.brunner@kontron.com>
 * Przemyslaw Rokosz <przemyslaw.rokosz@kontron.com>
 */

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/i2c.h>
#include <linux/mutex.h>
#include <linux/delay.h>

/* Addresses to scan */
static const unsigned short kontron_normal_i2c[] = { 0x50, I2C_CLIENT_END };
static int link_count;

/* Each client has this additional data */
struct kontron_eeep_data {
	struct mutex update_lock;
	u8 *eeprom;
	u16 u_area_start;
	u16 u_area_end;
};

static ssize_t kontron_eeep_read(struct file *filp, struct kobject *kobj,
			   struct bin_attribute *bin_attr,
			   char *buf, loff_t off, size_t count)
{
	struct i2c_client *client = to_i2c_client(container_of(kobj,
							       struct device,
							       kobj));
	struct kontron_eeep_data *data = i2c_get_clientdata(client);
	u8 off_low, off_high;
	int i, user_area_size;

	user_area_size = data->u_area_end - data->u_area_start + 1;

	if (off > user_area_size)
		return 0;
	if (off + count > user_area_size)
		count = user_area_size - off;

	off_low = (u8) ((data->u_area_start + off) & 0xff);
	off_high = (u8) (((data->u_area_start + off)>>8) & 0xff);

	mutex_lock(&data->update_lock);

	i2c_smbus_write_byte_data(client, off_high, off_low);

	for  (i = 0; i < count; i++) {
		int byte = i2c_smbus_read_byte(client);

		if (byte < 0) {
			dev_err(&client->dev, "address 0x%llx can't be read\n",
				(unsigned long long)off + i);
			mutex_unlock(&data->update_lock);
			return i;
		}
		buf[i] = byte & 0xff;
	}

	mutex_unlock(&data->update_lock);

	return count;
}

static ssize_t kontron_eeep_write(struct file *filp, struct kobject *kobj,
				struct bin_attribute *bin_attr,
				char *buf, loff_t off, size_t count)
{
	struct i2c_client *client = to_i2c_client(container_of(kobj,
							       struct device,
							       kobj));
	struct kontron_eeep_data *data = i2c_get_clientdata(client);

	u8 off_low, off_high;
	u16 word;
	int i, ret, user_area_size;

	user_area_size = data->u_area_end - data->u_area_start + 1;

	if (off > user_area_size)
		return 0;
	if (off + count > user_area_size)
		count = user_area_size - off;

	mutex_lock(&data->update_lock);

	for (i = 0; i < count; i++) {
		off_low = (u8) ((data->u_area_start + off + i) & 0xff);
		off_high = (u8) (((data->u_area_start + off + i) >> 8) & 0xff);
		word = buf[i] & 0xff;
		word = ((word << 8) | off_low);
		ret = i2c_smbus_write_word_data(client, off_high, word);
		if (ret < 0) {
			dev_err(&client->dev, "can't write to 0x%llx\n",
				(unsigned long long) off + i);
			mutex_unlock(&data->update_lock);
			return ret;
		}
		mdelay(20);	/* Twr from AT24C32A datasheet*/
	}

	mutex_unlock(&data->update_lock);

	return count;
}

static struct bin_attribute kontron_eeep_attr = {
	.attr = {
		.name = "kontron_eeep",
		.mode = 0660,
	},
	.read = kontron_eeep_read,
	.write = kontron_eeep_write,
};

/* Return 0 if detection is successful, -ENODEV otherwise */
static int kontron_eeep_detect(struct i2c_client *client, struct i2c_board_info
			       *info)
{
	struct i2c_adapter *adapter = client->adapter;

	if (!(adapter->class & I2C_CLASS_SPD) && client->addr >= 0x51)
		return -ENODEV;

	/* The EEEP sits on a real I2C interface */
	if (!i2c_check_functionality(adapter, I2C_FUNC_I2C))
		return -ENODEV;

	if (!i2c_check_functionality(adapter, I2C_FUNC_SMBUS_READ_BYTE)
	 && !i2c_check_functionality(adapter, I2C_FUNC_SMBUS_WRITE_BYTE)
	 && !i2c_check_functionality(adapter, I2C_FUNC_SMBUS_WRITE_BYTE_DATA)
	 && !i2c_check_functionality(adapter, I2C_FUNC_SMBUS_WRITE_WORD_DATA))
		return -ENODEV;

	strlcpy(info->type, "kontron_eeep", I2C_NAME_SIZE);

	return 0;
}

struct ee_blk_hdr {
	u8	type;
	int	size;
};

int ee_blk_read_hdr(struct i2c_client *client, int offset,
		    struct ee_blk_hdr *hdr)
{
	int byte;

	if (i2c_smbus_write_byte_data(client, offset >> 8, offset & 0xff))
		return -ENODEV;

	byte = i2c_smbus_read_byte(client);
	if (byte < 0)
		goto read_error;

	hdr->type = byte & 0xff;

	byte = i2c_smbus_read_byte(client);
	if (byte < 0)
		goto read_error;

	hdr->size = (byte & 0xff) << 8;
	byte = i2c_smbus_read_byte(client);
	if (byte < 0)
		goto read_error;
	hdr->size += byte & 0xff;
	hdr->size = hdr->size * 2;
	dev_dbg(&client->dev,
		"EEPP User block type 0x%02x at offset 0x%04x size %d\n",
			hdr->type, offset, hdr->size);

	return 0;

read_error:
	dev_err(&client->dev,
		"address can't be read eeprom\n");
	return byte;
}

int ee_find_usr_blk(struct i2c_client *client, int offset,
			u16 *ee_usr_start, u16 *ee_usr_end, u16 size)
{
	struct ee_blk_hdr blk;
	u8 eeprom[14];
	int i, err;

	do {
		err = ee_blk_read_hdr(client, offset, &blk);
		if (err < 0)
			goto read_error;

		/* only block sizes between 6 and 131069 are defined */
		if (blk.size < 6 || blk.size > 131069) {
			if (blk.size != 0)
				dev_err(&client->dev,
					"Unexpected block size (%d)\n",
					blk.size);
			return -ENODEV;
		}

		if (blk.type == 0xF0) {
			dev_dbg(&client->dev,
				"EEEP User found Vendor specific block\n");
			/* Searching in EEPROM for User Area */
			for  (i = 0; i < 14 - 3; i++) {
				int byte = i2c_smbus_read_byte(client);

				if (byte < 0) {
					err = byte;
					goto read_error;
				}
				eeprom[i] = byte & 0xff;
			}

			/* Verification block */
			if (eeprom[0] == 0xb5 &&
			    eeprom[1] == 0x2c &&
			    eeprom[3] == '$' &&
			    eeprom[4] == 'U' &&
			    eeprom[5] == 'S' &&
			    eeprom[6] == 'R') {
				*ee_usr_start = offset + 14;
				*ee_usr_end = offset + blk.size - 1;

				dev_info(&client->dev,
					 "EEEP User area version %d.%d\n",
					 eeprom[7] >> 4, eeprom[7] & 0x0F);
				return 0;
			}
		}

		/* go to next block */
		offset += blk.size;

	} while ((offset + 14) < size);

	return -ENODEV;

read_error:
	dev_err(&client->dev,
		"address 0x%x can't be read\n", i);
	return err;
}


int ee_find_usr_blk_old(struct i2c_client *client, int offset,
			u16 *ee_usr_start, u16 *ee_usr_end, u16 size)
{
	u8 *eeprom = NULL;
	int err;
	int i;

	eeprom = kzalloc(size, GFP_KERNEL);
	if (!eeprom) {
		err = -ENOMEM;
		goto exit;
	}

	/* Jump to dynamic blocks */
	/*
	 * Don't use word wise addressing right now, as there is still a tiny
	 * chance that this is not a valid EEEP device
	 */
	if (i2c_smbus_write_byte_data(client, 0, offset)) {
		err = -ENODEV;
		goto exit_kfree;
	}

	/* Searching in EEPROM for User Area */
	for  (i = offset; i < size - 16; i++) {
		int byte = i2c_smbus_read_byte(client);

		if (byte < 0) {
			dev_err(&client->dev,
				"address 0x%x can't be read\n", i);
			err = byte;
			goto exit_kfree;
		}
		eeprom[i] = byte & 0xff;
	}

	for (i = offset; i < size - 16; i++) {
		if ((eeprom[i] == 0xf0)
		    && (eeprom[i+3] == 0x2c)
		    && (eeprom[i+4] == 0xad)
		    && (eeprom[i+5] == 0x01)
		    && (eeprom[i+6] == 0x24)
		    && (eeprom[i+7] == 0x55)
		    && (eeprom[i+8] == 0x53)
		    && (eeprom[i+9] == 0x52)) {
			*ee_usr_start = i + 0x0e;
			*ee_usr_end = i + 2 * ((eeprom[i+1]<<8)
					       | eeprom[i+2]) - 1;
		}
	}

	kfree(eeprom);
	return 0;

exit_kfree:
	kfree(eeprom);
exit:
	return err;
}

static int kontron_eeep_probe(struct i2c_client *client,
			const struct i2c_device_id *id)
{
	struct kontron_eeep_data *data;
	int user_area_size;
	int err;
	int eeep_spec_rev;
	int offset;
	int descriptor;
	int size;

	data = kzalloc(sizeof(struct kontron_eeep_data), GFP_KERNEL);
	if (!data) {
		err = -ENOMEM;
		goto exit;
	}

	i2c_set_clientdata(client, data);

	mutex_init(&data->update_lock);

	mutex_lock(&data->update_lock);
	if (i2c_smbus_write_byte_data(client, 0x0, 0x1)) {
		err = -ENODEV;
		goto exit_kfree;
	}
	if (i2c_smbus_read_byte(client) != '3') {
		err = -ENODEV;
		goto exit_kfree;
	}
	if (i2c_smbus_read_byte(client) != 'P') {
		err = -ENODEV;
		goto exit_kfree;
	}
	eeep_spec_rev = i2c_smbus_read_byte(client);
	if (eeep_spec_rev < 0) {
		err = -ENXIO;
		goto exit_kfree;
	}
	dev_info(&client->dev, "EEEP Specification Revision %d\n",
		eeep_spec_rev);

	offset = i2c_smbus_read_byte(client);
	if (offset < 0) {
		err = -ENXIO;
		goto exit_kfree;
	}
	offset *= 2;

	descriptor = i2c_smbus_read_byte(client);
	if (descriptor < 0) {
		err = -ENXIO;
		goto exit_kfree;
	}

	size = (256 << (descriptor & 0xf));
	dev_info(&client->dev, "EEPROM Size %d byte\n", size);

	if (!(descriptor & 0x10)) {
		dev_err(&client->dev,
			"Standard index EEEPROM is not supported\n");
		err = -ENODEV;
		goto exit_kfree;
	}

	/* 1  - Detect new kontron eeprom structure */
	err = ee_find_usr_blk(client, offset, &data->u_area_start,
			      &data->u_area_end, size);
	if (err < 0) {
		/* 2 - Try use old kontron eeprom structure */
		err = ee_find_usr_blk_old(client, offset, &data->u_area_start,
					  &data->u_area_end, size);
	}

	mutex_unlock(&data->update_lock);


	if (err < 0 || !data->u_area_end) {
		dev_err(&client->dev, "can't find user area\n");
		err = -ENODEV;
		goto exit_kfree;
	}

	user_area_size = data->u_area_end - data->u_area_start + 1;


	dev_info(&client->dev, "EEPROM User area at 0x%x (%d byte)\n",
		data->u_area_start, user_area_size);

	kontron_eeep_attr.size = user_area_size;

	/* create the sysfs eeprom file */
	err = sysfs_create_bin_file(&client->dev.kobj,
				    &kontron_eeep_attr);
	if (err)
		goto exit_kfree;
	/* register a link in kernel/ */
	if (!link_count++) {
		err = sysfs_create_link(kernel_kobj, &client->dev.kobj,
					"kontron_eeep");
		if (err)
			goto exit_kfree_1;
	}


	return 0;

exit_kfree_1:
	sysfs_remove_bin_file(&client->dev.kobj, &kontron_eeep_attr);
exit_kfree:
	kfree(data);
exit:
	return err;
}

static int kontron_eeep_remove(struct i2c_client *client)
{
	if (link_count--)
		sysfs_remove_link(kernel_kobj, "kontron_eeep");
	sysfs_remove_bin_file(&client->dev.kobj, &kontron_eeep_attr);
	kfree(i2c_get_clientdata(client));

	return 0;
}

static const struct i2c_device_id kontron_eeep_id[] = {
	{ "kontron_eeep", 0 },
	{ }
};

static struct i2c_driver kontron_eeep_driver = {
	.driver = {
		.name	= "kontron_eeep",
	},
	.probe		= kontron_eeep_probe,
	.remove		= kontron_eeep_remove,
	.id_table	= kontron_eeep_id,

	.class		= I2C_CLASS_SPD,
	.detect		= kontron_eeep_detect,
	.address_list	= kontron_normal_i2c,
};

static int __init kontron_eeep_init(void)
{
	return i2c_add_driver(&kontron_eeep_driver);
}

static void __exit kontron_eeep_exit(void)
{
	i2c_del_driver(&kontron_eeep_driver);
}

module_init(kontron_eeep_init);
module_exit(kontron_eeep_exit);

MODULE_AUTHOR("Michael Brunner <michael.brunner@kontron.com");
MODULE_DESCRIPTION("Kontron Embedded EEPROM driver");
MODULE_LICENSE("GPL");
MODULE_ALIAS("i2c:kontron_eeep");
MODULE_VERSION("11.0");
